package com.basketball;

public enum PositionTypes {
    POINT_GUARD, SHOOTING_GUARD, SMALL_FORWARD, POWER_FORWARD, CENTER
}
